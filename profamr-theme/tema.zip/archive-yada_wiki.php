<?php
/*
Template Name: Yada Wiki Archive
Template Post Type: wiki
*/
get_header();
?>

<div id="primary" class="content-area wiki-archive-content">
    <main id="main" class="site-main">

        <header class="page-header">
            <h1 class="page-title">
                <?php
                // Título da página de arquivo para o Yada Wiki
                echo 'Artigos Wiki'; // Você pode personalizar este título
                ?>
            </h1>
        </header><!-- .page-header -->

        <?php
        if ( have_posts() ) :
            /* Start the Loop */
            while ( have_posts() ) :
                the_post();

                /*
                 * Include the Post-Type-specific template for the content.
                 * If you want a different layout for each wiki item in the archive,
                 * you could create a content-wiki.php and call it here.
                 */
                ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class( 'wiki-archive-item' ); ?>>
                    <header class="entry-header">
                        <?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
                    </header><!-- .entry-header -->

                    <div class="entry-summary">
                        <?php the_excerpt(); // Exibe um resumo do conteúdo da wiki ?>
                    </div><!-- .entry-summary -->

                    <footer class="entry-footer">
                        <?php
                        // Você pode adicionar metadados aqui, como data, autor, categorias, etc.
                        printf(
                            '<span class="posted-on">Publicado em: <a href="%1$s" rel="bookmark"><time class="entry-date published updated" datetime="%2$s">%3$s</time></a></span>',
                            esc_url( get_permalink() ),
                            esc_attr( get_the_date( DATE_W3C ) ),
                            esc_html( get_the_date() )
                        );
                        ?>
                    </footer><!-- .entry-footer -->
                </article><!-- #post-<?php the_ID(); ?> -->
                <?php

            endwhile;

            the_posts_navigation(); // Adiciona links de navegação para posts (anterior/próximo)

        else :

            // Se não houver posts wiki para exibir
            ?>
            <section class="no-results not-found">
                <header class="page-header">
                    <h1 class="page-title"><?php esc_html_e( 'Nenhum Artigo Wiki Encontrado', 'your-text-domain' ); ?></h1>
                </header><!-- .page-header -->

                <div class="page-content">
                    <p><?php esc_html_e( 'Parece que não há artigos wiki para exibir aqui.', 'your-text-domain' ); ?></p>
                </div><!-- .page-content -->
            </section><!-- .no-results -->
            <?php

        endif;
        ?>

    </main><!-- #main -->
</div><!-- #primary -->

<?php
get_sidebar('wiki');
get_footer();
?>
