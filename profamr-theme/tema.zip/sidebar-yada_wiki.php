<?php
/**
 * The sidebar containing the main widget area for Wiki pages.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#sidebar-php
 */

if ( ! is_active_sidebar( 'sidebar-wiki'  ) ) {
    // Se não houver widgets registrados para esta sidebar, podemos exibir um menu de categorias padrão.
    // Ou você pode simplesmente retornar se não quiser exibir nada.
    // return;
}
?>

<aside id="secondary" class="widget-area wiki-sidebar">
    <div class="widget widget_categories">
        <h2 class="widget-title">Conteúdo Wiki</h2>
        <ul>
            <?php
            // Parâmetros para wp_list_categories
            $args = array(
                'orderby'            => 'name',
                'order'              => 'ASC',
                'show_count'         => 0,   // Não mostrar a contagem de posts
                'hide_empty'         => 0,   // Mostrar categorias mesmo que vazias
                'use_desc_for_title' => 0,   // Não usar descrição como título
                'child_of'           => 0,   // ID da categoria pai (0 para todas as categorias de nível superior)
                'hierarchical'       => 1,   // Exibir categorias hierarquicamente (aninhadas)
                'title_li'           => '',  // Não exibir o título padrão da lista (já temos um h2)
                'depth'              => 0,   // Profundidade da hierarquia (0 para todos os níveis)
                'taxonomy'           => 'category', // A taxonomia que você quer listar (geralmente 'category' para posts normais)
                // Se o Yada Wiki usa uma taxonomia personalizada para suas categorias, você precisará mudar 'category' para o nome dessa taxonomia.
                // Por exemplo, se for 'wiki_category', use 'taxonomy' => 'wiki_category'.
                // Verifique a documentação do Yada Wiki ou o código-fonte para confirmar.
            );

            wp_list_categories( $args );
            ?>
        </ul>
    </div><!-- .widget_categories -->

    <?php dynamic_sidebar( 'sidebar-wiki' ); // Permite adicionar widgets via painel do WordPress ?>
</aside><!-- #secondary -->
